import Meta from 'gi://Meta';
import Shell from 'gi://Shell';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import { Extension } from "resource:///org/gnome/shell/extensions/extension.js";
export default class MonitorUtilsExtension extends Extension {
    _settings;
    primaryMonitorIndex = 0;
    secondaryMonitorIndex = 0;
    enable() {
        this._settings = this.getSettings();
        this.primaryMonitorIndex = global.display.get_primary_monitor();
        this.secondaryMonitorIndex = this._settings.get_int('secondary-monitor');
        Main.wm.addKeybinding('swap-monitors-keybind', this._settings, Meta.KeyBindingFlags.IGNORE_AUTOREPEAT, Shell.ActionMode.NORMAL, this._swap_monitors.bind(this));
    }
    disable() {
        Main.wm.removeKeybinding('swap-monitors-keybind');
    }
    _swap_monitors() {
        const focusedMonitorIndex = global.display.get_focus_window().get_monitor();
        const swapOrigin = focusedMonitorIndex;
        const swapTarget = focusedMonitorIndex === this.primaryMonitorIndex ? this.secondaryMonitorIndex : this.primaryMonitorIndex;
        if (swapOrigin === swapTarget)
            return;
        // const swapped: number[] = [];
        for (const window of global.display.list_all_windows()) {
            if (window.get_monitor() === swapOrigin) {
                window.move_to_monitor(swapTarget);
                continue;
                // swapped.push(window.get_id());
            }
            if (window.get_monitor() === swapTarget) {
                window.move_to_monitor(swapOrigin);
                continue;
                // swapped.push(window.get_id());
            }
        }
    }
}
